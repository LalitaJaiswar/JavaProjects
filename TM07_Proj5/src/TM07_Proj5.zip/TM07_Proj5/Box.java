public class Box {
	double length,width,height;
	Box(double length,double width,double height){
		this.height=height;
		this.length=length;
		this.width=width;
	}
}
